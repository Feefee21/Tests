elements.human.reactions = {
    "milk": { "elem1":"explosion"},
    "wheat": { "elem1":"explosion"},
	"bread": { "elem1":"explosion"},
	"toast": { "elem1":"explosion"}
};
elements.body.reactions = {
    "milk": { "elem1":"explosion"},
    "wheat": { "elem1":"explosion"},
	"bread": { "elem1":"explosion"},
	"toast": { "elem1":"explosion"}
};
elements.head.reactions = {
    "milk": { "elem1":"explosion"},
    "wheat": { "elem1":"explosion"},
	"bread": { "elem1":"explosion"},
	"toast": { "elem1":"explosion"}
}
